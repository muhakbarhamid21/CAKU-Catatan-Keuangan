package com.caku.caku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
