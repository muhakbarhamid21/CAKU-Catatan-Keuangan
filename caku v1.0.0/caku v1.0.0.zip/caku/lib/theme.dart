import 'package:flutter/material.dart';

Color PrimaryColor = Color(0xff009dc4);

MaterialColor PrimaryMaterialColor = MaterialColor(
  4278562850,
  <int, Color>{
    50: Color.fromRGBO(
      0,
      157,
      196,
      .1,
    ),
    100: Color.fromRGBO(
      0,
      157,
      196,
      .2,
    ),
    200: Color.fromRGBO(
      0,
      157,
      196,
      .3,
    ),
    300: Color.fromRGBO(
      0,
      157,
      196,
      .4,
    ),
    400: Color.fromRGBO(
      0,
      157,
      196,
      .5,
    ),
    500: Color.fromRGBO(
      0,
      157,
      196,
      .6,
    ),
    600: Color.fromRGBO(
      0,
      157,
      196,
      .7,
    ),
    700: Color.fromRGBO(
      0,
      157,
      196,
      .8,
    ),
    800: Color.fromRGBO(
      0,
      157,
      196,
      .9,
    ),
    900: Color.fromRGBO(
      0,
      157,
      196,
      .1,
    ),
  },
);
